# User Flow Illustrations (Text + Mermaid)

These illustrate what users see when entering expected data.

```mermaid
flowchart TD
  A[Home] --> B[Login/Register]
  A --> C[Events]
  C --> D[Event Detail]
  D --> E[Add to Cart]
  E --> F[Checkout]
  F --> G[Order Confirmation]
  G --> H[Dashboard (Orders)]

  C -->|Organizer| I[Create Event]
  I --> C
  B -->|Admin| J[Admin Panel]
  J --> C
```

## Scenarios
### Guest → Attendee
1. Visit **Home** → click **Events**.
2. Filter, select an event → **Event Detail**.
3. Add 2 tickets → **Checkout** → enter valid payment fields.
4. **Order Confirmation** → **Dashboard** shows the order.

### Organizer
1. Login (role=Organizer) → **Create Event**.
2. Fill form (Title/Date/Venue/Price/Seats/Desc) → Save.
3. Event appears in **Events** and **Admin** list (mocked).

### Admin
1. Login (role=Admin) → **Admin Panel**.
2. Search/sort **Users**; edit roles (mock).
3. Manage **Events** (edit/delete) (mock).

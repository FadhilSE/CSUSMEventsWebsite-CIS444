# CSUSM Campus Events — Phase 1 (UI Complete, DB Mocked)

This submission implements the full **UI/UX** and page flow for the term project, following W3C-valid HTML/CSS and unobtrusive JavaScript. Database calls are **mocked** using `localStorage` to show how pages will work.

## How to run
- Open `index.html` in any modern browser or deploy this folder to your class server document root.

## Highlights
- Semantic HTML, ARIA labels, and responsive layout.
- Error pages: `404.html`, `500.html`.
- User flows: guest browsing, registration/login, cart/checkout, organizer create event, admin user/event management.
- Sorting, add/edit/delete are simulated; replace localStorage stubs with real API calls in Phase 2.

## Structure
- `assets/css/styles.css`
- `assets/js/app.js` — data models, mock store, routing helpers
- `assets/js/validators.js` — basic client validation
- Pages: `index.html`, `events.html`, `event.html`, `login.html`, `register.html`, `dashboard.html`, `admin.html`, `create_event.html`, `checkout.html`, `orders.html`, `404.html`, `500.html`
- Docs: improved plan, user flows, minutes, access, third-party notes

## Validation
- HTML and CSS are designed to validate on W3C validators. Avoid inline styles except minor layout notes and ensure attributes are valid.

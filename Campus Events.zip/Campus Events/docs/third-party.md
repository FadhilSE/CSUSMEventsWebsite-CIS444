# Third-Party Software

Currently **no third-party runtime libraries** are required for the site.
- Rationale: This phase practices raw **HTML, CSS, JavaScript** skills and keeps validation simple.
- Allowed developer tools (outside runtime): Prettier/ESLint (optional), a11y linters.

If you later add tools (e.g., date picker, chart lib), ensure:
- They validate to W3C HTML/CSS.
- They are accessible and responsive.
- You document exactly **why** you needed them and how you used them.

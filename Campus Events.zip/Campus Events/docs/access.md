# Source Control Access

Provide access (invite or credentials) to your repository here.

- **Host**: GitHub (recommended)
- **Repo URL**: _add your link here_
- **Members**: add teammates
- **Branching**: `main` (protected), feature branches via PRs
- **Created**: 2025-10-21

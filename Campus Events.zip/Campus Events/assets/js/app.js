
/* CSUSM Campus Events — Phase 1 Mock Data + UI Wiring (no DB yet) */
(function(){
  const store = {
    key: 'csusm-events',
    read(){
      try { return JSON.parse(localStorage.getItem(this.key)) || {} } catch(e){ return {} }
    },
    write(data){ localStorage.setItem(this.key, JSON.stringify(data)) }
  };
  const state = store.read();
  if(!state.events){
    state.events = [
      {id:'e1', title:'Hackathon', date:'2025-11-05', venue:'Library Hall', price:0, seats:200, desc:'24-hour student hackathon', category:'Career'},
      {id:'e2', title:'Career Fair', date:'2025-11-12', venue:'USU Ballroom', price:0, seats:500, desc:'Meet employers on campus', category:'Career'},
      {id:'e3', title:'Open Mic Night', date:'2025-11-08', venue:'Amphitheater', price:5, seats:120, desc:'Share your talent', category:'Social'},
      {id:'e4', title:'Data Science Talk', date:'2025-11-15', venue:'SCI 2-242', price:0, seats:80, desc:'Guest speaker from industry', category:'Academic'}
    ];
  }
  if(!state.users){
    state.users = [
      {email:'admin@csusm.edu', role:'Admin'},
      {email:'org@csusm.edu', role:'Organizer'},
      {email:'student@csusm.edu', role:'Attendee'}
    ];
  }
  if(!state.orders) state.orders = [];
  if(!state.cart) state.cart = [];
  if(!state.session) state.session = null;
  store.write(state);

  // Helpers
  const $ = sel => document.querySelector(sel);
  const $$ = sel => Array.from(document.querySelectorAll(sel));
  function navTo(url){ location.href = url }

  // Featured
  const featuredList = $('#featuredList');
  if(featuredList){
    featuredList.innerHTML = state.events.slice(0,3).map(card).join('');
  }

  // Quick search
  const searchForm = $('#searchForm');
  if(searchForm){
    searchForm.addEventListener('submit', e=>{
      e.preventDefault();
      const q = $('#q').value.trim();
      const type = $('#type').value;
      sessionStorage.setItem('filters', JSON.stringify({kw:q, cat:type}));
      navTo('events.html');
    });
  }

  // Events page
  const eventList = $('#eventList');
  if(eventList){
    const filters = JSON.parse(sessionStorage.getItem('filters')||'{}');
    $('#kw').value = filters.kw || '';
    $('#cat').value = filters.cat || '';
    renderEvents();
    $('#filters').addEventListener('submit', e=>{
      e.preventDefault(); renderEvents();
    });
  }
  function renderEvents(){
    const kw = ($('#kw')?.value || '').toLowerCase();
    const cat = $('#cat')?.value || '';
    const sort = $('#sort')?.value || 'date';
    let items = state.events.filter(ev =>
      (!kw || ev.title.toLowerCase().includes(kw) || ev.desc.toLowerCase().includes(kw)) &&
      (!cat || ev.category===cat)
    );
    items.sort((a,b)=>{
      if(sort==='date') return a.date.localeCompare(b.date);
      if(sort==='title') return a.title.localeCompare(b.title);
      if(sort==='price') return (a.price||0) - (b.price||0);
      return 0;
    });
    eventList.innerHTML = items.map(card).join('');
    $$('#eventList .btn').forEach(btn=>{
      btn.addEventListener('click', e=>{
        const id = e.currentTarget.getAttribute('data-id');
        sessionStorage.setItem('event', id);
        navTo('event.html');
      });
    });
  }

  // Event detail
  if($('#eventDetail')){
    const id = sessionStorage.getItem('event') || state.events[0]?.id;
    const ev = state.events.find(x=>x.id===id) || state.events[0];
    $('#evTitle').textContent = ev.title;
    $('#evDate').textContent = ev.date;
    $('#evVenue').textContent = ev.venue;
    $('#evDesc').textContent = ev.desc;
    $('#addToCart').addEventListener('submit', e=>{
      e.preventDefault();
      const qty = parseInt($('#qty').value,10) || 1;
      state.cart.push({id:ev.id, title:ev.title, price:ev.price, qty});
      store.write(state);
      navTo('checkout.html');
    });
  }

  // Checkout
  const checkoutForm = $('#checkoutForm');
  if(checkoutForm){
    checkoutForm.addEventListener('submit', e=>{
      e.preventDefault();
      const total = state.cart.reduce((s,i)=> s + (i.price||0)*i.qty, 0);
      const order = { id: `O${Date.now()}`, date: new Date().toISOString().slice(0,10), items: state.cart.slice(), total, status:'Confirmed' };
      state.orders.unshift(order);
      state.cart = [];
      store.write(state);
      $('#checkoutMsg').hidden = false;
      $('#checkoutMsg').textContent = `Order ${order.id} placed!`;
      setTimeout(()=> navTo('orders.html'), 700);
    });
  }

  // Orders/Dashboard
  const ordersTbody = $('#ordersTbody');
  if(ordersTbody){
    ordersTbody.innerHTML = state.orders.map(o=>{
      const items = o.items.map(i=>`${i.title} × ${i.qty}`).join(', ');
      return `<tr><td>${o.id}</td><td>${o.date}</td><td>${items}</td><td>$${o.total.toFixed(2)}</td><td>${o.status}</td></tr>`;
    }).join('') || `<tr><td colspan="5">No orders yet.</td></tr>`;
  }

  // Admin users/events
  const userTbody = $('#userTbody');
  const adminEvents = $('#adminEvents');
  if(userTbody){
    renderUsers();
    $('#uSearch').addEventListener('input', renderUsers);
    $('#uSort').addEventListener('change', renderUsers);
  }
  if(adminEvents){
    renderAdminEvents();
  }
  function renderUsers(){
    const q = ($('#uSearch')?.value || '').toLowerCase();
    const sort = $('#uSort')?.value || 'email';
    let users = state.users.filter(u => !q || u.email.toLowerCase().includes(q) || u.role.toLowerCase().includes(q));
    users.sort((a,b)=> a[sort].localeCompare(b[sort]));
    userTbody.innerHTML = users.map(u => `
      <tr><td>${u.email}</td><td>${u.role}</td>
      <td><button class="btn ghost" data-e="${u.email}" data-act="promote">Promote</button>
          <button class="btn ghost" data-e="${u.email}" data-act="delete">Delete</button></td></tr>`).join('');
    userTbody.querySelectorAll('button').forEach(b=>{
      b.addEventListener('click', e=>{
        const email = e.currentTarget.getAttribute('data-e');
        const act = e.currentTarget.getAttribute('data-act');
        const idx = state.users.findIndex(x=>x.email===email);
        if(idx<0) return;
        if(act==='delete'){ state.users.splice(idx,1); }
        if(act==='promote'){ state.users[idx].role = 'Admin'; }
        store.write(state); renderUsers();
      });
    });
  }
  function renderAdminEvents(){
    adminEvents.innerHTML = state.events.map(ev => `
      <tr><td>${ev.title}</td><td>${ev.date}</td><td>${ev.seats}</td>
      <td><button class="btn ghost" data-id="${ev.id}" data-act="edit">Edit</button>
          <button class="btn ghost" data-id="${ev.id}" data-act="delete">Delete</button></td></tr>`).join('');
    adminEvents.querySelectorAll('button').forEach(b=>{
      b.addEventListener('click', e=>{
        const id = e.currentTarget.getAttribute('data-id');
        const act = e.currentTarget.getAttribute('data-act');
        const idx = state.events.findIndex(x=>x.id===id);
        if(idx<0) return;
        if(act==='delete'){ state.events.splice(idx,1); }
        if(act==='edit'){
          const t = prompt('New title', state.events[idx].title);
          if(t){ state.events[idx].title = t; }
        }
        store.write(state); renderAdminEvents();
      });
    });
  }

  // Create event
  const createForm = $('#createEventForm');
  if(createForm){
    createForm.addEventListener('submit', e=>{
      e.preventDefault();
      const ev = {
        id: 'e' + (Date.now()),
        title: $('#title').value.trim(),
        date: $('#date').value,
        venue: $('#venue').value.trim(),
        price: parseFloat($('#price').value)||0,
        seats: parseInt($('#seats').value,10)||0,
        desc: $('#desc').value.trim(),
        category: 'Academic'
      };
      if(!ev.title || !ev.date){ alert('Title and Date required'); return; }
      state.events.unshift(ev);
      store.write(state);
      alert('Saved (mock).');
      navTo('events.html');
    });
  }

  function card(ev){
    return `
    <article class="card" aria-label="${ev.title}">
      <h3>${ev.title}</h3>
      <p>${ev.date} · ${ev.venue}</p>
      <p>${ev.desc}</p>
      <p><strong>$${(ev.price||0).toFixed(2)}</strong></p>
      <button class="btn" data-id="${ev.id}">View</button>
    </article>`;
  }
})();


// Minimal client-side validators for forms
(function(){
  const reg = document.getElementById('registerForm');
  if(reg){
    reg.addEventListener('submit', e=>{
      const p1 = document.getElementById('pass1').value;
      const p2 = document.getElementById('pass2').value;
      const msg = document.getElementById('regMsg');
      if(p1 !== p2){
        e.preventDefault();
        msg.hidden = false; msg.textContent = 'Passwords do not match.';
      }
    });
  }
  const login = document.getElementById('loginForm');
  if(login){
    login.addEventListener('submit', e=>{
      e.preventDefault();
      const email = document.getElementById('email').value.trim();
      const msg = document.getElementById('loginMsg');
      if(!/^[^@]+@[^@]+\.[^@]+$/.test(email)){
        msg.hidden = false; msg.textContent = 'Enter a valid email.';
        return;
      }
      msg.classList.remove('alert'); msg.classList.add('success');
      msg.hidden = false; msg.textContent = 'Logged in (mock).';
      setTimeout(()=> location.href='dashboard.html', 600);
    });
  }
})();
